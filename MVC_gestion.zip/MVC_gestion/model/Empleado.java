package model;

public class Empleado {
          
}
