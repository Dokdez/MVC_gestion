package view;

//Librerias de Java AWT y Swing
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaEmpleado extends Frame {

    // Componentes de la interfaz gráfica
   

  
    // Constructor de la ventana
    public VentanaEmpleado() {
        setLayout(null);
        setSize(1000, 400);
        setTitle("Sistema de Pago - MVP");
        setBackground(Color.PINK);
        setLocationRelativeTo(null);
        configurarCamposDeEntradas();
        configurarBotonesDeEventos();
        configurarTablaDeDatos();
        configurarEventos();
    }

    // Método de configuración para los campos de entrada
    private void configurarCamposDeEntradas() {
       
    }

    // Método para configurar la tabla de datos
    private void configurarTablaDeDatos() {
       
    }

    // Método para configurar los botones y sus eventos
    private void configurarBotonesDeEventos() {
       
    }

    // Método para los eventos de los botones
    private void configurarEventos() {
       

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
