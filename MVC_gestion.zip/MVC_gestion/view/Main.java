package view;

public class Main {
    public static void main(String[] args) {
        // Crea una instancia de la ventana principal de la aplicación
        VentanaEmpleado miVentana = new VentanaEmpleado();
        miVentana.setVisible(true); // Hace visible la ventana en la interfaz gráfica
    }
}
 