package controller;

public class ControladorEmpleado {

    // Método para agregar un nuevo registro a la base de datos y a la tabla
    public void agregarRegistro() {
       
    }

    // Método para cargar todos los registros de la base de datos en la tabla
    public void cargarRegistros() {
        
    }


    // Método para modificar un registro en la base de datos y en la tabla
    public void modificarRegistro() {
       
    }

    // Método para eliminar un registro de la base de datos y de la tabla
    public void eliminarRegistro() {
       
    }   


    // Método para consultar un registro 
    public void consultarRegistro() {
        
    }    
}
